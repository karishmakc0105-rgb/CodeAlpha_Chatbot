from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

responses = {
    "hello": "Hi! How can I help you today?",
    "hi": "Hello there!",
    "how are you": "I'm doing great!",
    "bye": "Goodbye! Have a nice day.",
    "what is your name": "I am CodeAlpha Chatbot."
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json['message'].lower()

    reply = responses.get(user_message,
                          "Sorry, I don't understand that.")

    return jsonify({'reply': reply})

if __name__ == '__main__':
    app.run(debug=True)
